/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./react-client/src/index.jsx");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./config.js":
/*!*******************!*\
  !*** ./config.js ***!
  \*******************/
/*! no static exports found */
/***/ (function(module, exports) {

eval("// aws config\n// module.exports = {\n//   mongoUri: 'mongodb://172.31.46.64:27017/itemAvailability',\n//   itemPrice: 'http://52.14.208.55:3005/itemPrice/',\n//   availableAt: 'http://18.224.229.28:3006/availableAt/'\n\n// };\n\n//local config\nmodule.exports = {\n  mongoUri: 'mongodb://localhost/itemAvailability',\n  itemPrice: 'http://127.0.0.1:3005/itemPrice/',\n  availableAt: 'http://127.0.0.1:3006/availableAt/'\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9jb25maWcuanMuanMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vLi9jb25maWcuanM/YTFiYyJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBhd3MgY29uZmlnXG4vLyBtb2R1bGUuZXhwb3J0cyA9IHtcbi8vICAgbW9uZ29Vcmk6ICdtb25nb2RiOi8vMTcyLjMxLjQ2LjY0OjI3MDE3L2l0ZW1BdmFpbGFiaWxpdHknLFxuLy8gICBpdGVtUHJpY2U6ICdodHRwOi8vNTIuMTQuMjA4LjU1OjMwMDUvaXRlbVByaWNlLycsXG4vLyAgIGF2YWlsYWJsZUF0OiAnaHR0cDovLzE4LjIyNC4yMjkuMjg6MzAwNi9hdmFpbGFibGVBdC8nXG5cbi8vIH07XG5cbi8vbG9jYWwgY29uZmlnXG5tb2R1bGUuZXhwb3J0cyA9IHtcbiAgbW9uZ29Vcmk6ICdtb25nb2RiOi8vbG9jYWxob3N0L2l0ZW1BdmFpbGFiaWxpdHknLFxuICBpdGVtUHJpY2U6ICdodHRwOi8vMTI3LjAuMC4xOjMwMDUvaXRlbVByaWNlLycsXG4gIGF2YWlsYWJsZUF0OiAnaHR0cDovLzEyNy4wLjAuMTozMDA2L2F2YWlsYWJsZUF0Lydcbn1cbiJdLCJtYXBwaW5ncyI6IkFBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTsiLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./config.js\n");

/***/ }),

/***/ "./react-client/src/DeliverPickup.jsx":
/*!********************************************!*\
  !*** ./react-client/src/DeliverPickup.jsx ***!
  \********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);\n\n\nvar DeliverPickup = function DeliverPickup(props) {\n  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(\"div\", {\n    className: \"deliveryPickupContainers\"\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(\"div\", {\n    className: \"deliverPickup\"\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(\"div\", {\n    className: \"deliverPickupHeader\"\n  }, \"Deliver it To Me\"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(\"div\", {\n    className: \"deliverPickupItemPrice\"\n  }, props.currency, props.price), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(\"div\", {\n    className: \"deliverText\"\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(\"div\", {\n    className: \"deliveryTruck\"\n  }), \" Order now to get it by \", /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(\"span\", {\n    className: \"deliveryDate\"\n  }, \"Wednesday, August 22\")), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(\"button\", {\n    className: \"deliverPickupButton\"\n  }, \"Add to Cart\"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(\"div\", {\n    className: \"addToWishlistDiv\"\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(\"a\", {\n    className: \"addToWishlist\"\n  }, \"Add to Wishlist\"))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(\"div\", {\n    className: \"deliverPickup\"\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(\"div\", {\n    className: \"deliverPickupHeader\"\n  }, \"I'll Pick It Up\"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(\"div\", {\n    className: \"cubsidePickup\"\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(\"strong\", null, \"10% off \\u2013 See Price in Cart!\"), \" Curbside pickup now available in most locations.\"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(\"div\", {\n    className: \"deliverPickupItemPrice\"\n  }, props.currency, props.price), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(\"div\", {\n    className: \"itemAvailability \".concat(props.availability.availability ? 'itemAvailabilityGreen' : 'itemAvailabilityRed')\n  }, props.availability.availability ? \"Available at:\" : \"Not Available at:\"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(\"div\", {\n    className: \"localStoreAvailability\"\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(\"span\", {\n    className: \"pickupStoreName\"\n  }, props.availability.storeName.toUpperCase()), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(\"a\", {\n    className: \"changeStore\"\n  }, \"Change Store\")), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(\"button\", {\n    disabled: !props.availability.availability,\n    className: \"deliverPickupButton\"\n  }, props.availability.availability ? \"Add to Cart\" : \"Not Available\")));\n};\n\n/* harmony default export */ __webpack_exports__[\"default\"] = (DeliverPickup);//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9yZWFjdC1jbGllbnQvc3JjL0RlbGl2ZXJQaWNrdXAuanN4LmpzIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vLy4vcmVhY3QtY2xpZW50L3NyYy9EZWxpdmVyUGlja3VwLmpzeD80ZTI5Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XG4gICBcbmNvbnN0IERlbGl2ZXJQaWNrdXAgPSAocHJvcHMpID0+IChcbiAgPGRpdiBjbGFzc05hbWU9XCJkZWxpdmVyeVBpY2t1cENvbnRhaW5lcnNcIj5cbiAgICA8ZGl2IGNsYXNzTmFtZT1cImRlbGl2ZXJQaWNrdXBcIj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZGVsaXZlclBpY2t1cEhlYWRlclwiPkRlbGl2ZXIgaXQgVG8gTWU8L2Rpdj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZGVsaXZlclBpY2t1cEl0ZW1QcmljZVwiPntwcm9wcy5jdXJyZW5jeX17cHJvcHMucHJpY2V9PC9kaXY+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImRlbGl2ZXJUZXh0XCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZGVsaXZlcnlUcnVja1wiPjwvZGl2PiBPcmRlciBub3cgdG8gZ2V0IGl0IGJ5IDxzcGFuIGNsYXNzTmFtZT1cImRlbGl2ZXJ5RGF0ZVwiPldlZG5lc2RheSwgQXVndXN0IDIyPC9zcGFuPlxuICAgICAgPC9kaXY+XG4gICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cImRlbGl2ZXJQaWNrdXBCdXR0b25cIj5BZGQgdG8gQ2FydDwvYnV0dG9uPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJhZGRUb1dpc2hsaXN0RGl2XCI+XG4gICAgICAgIDxhIGNsYXNzTmFtZT1cImFkZFRvV2lzaGxpc3RcIj5BZGQgdG8gV2lzaGxpc3Q8L2E+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgICA8ZGl2IGNsYXNzTmFtZT1cImRlbGl2ZXJQaWNrdXBcIj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZGVsaXZlclBpY2t1cEhlYWRlclwiPkknbGwgUGljayBJdCBVcDwvZGl2PlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJjdWJzaWRlUGlja3VwXCI+XG4gICAgICAgIDxzdHJvbmc+MTAlIG9mZiDigJMgU2VlIFByaWNlIGluIENhcnQhPC9zdHJvbmc+IEN1cmJzaWRlIHBpY2t1cCBub3cgYXZhaWxhYmxlIGluIG1vc3QgbG9jYXRpb25zLlxuICAgICAgPC9kaXY+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImRlbGl2ZXJQaWNrdXBJdGVtUHJpY2VcIj57cHJvcHMuY3VycmVuY3l9e3Byb3BzLnByaWNlfTwvZGl2PlxuICAgICAgPGRpdiBjbGFzc05hbWU9e2BpdGVtQXZhaWxhYmlsaXR5ICR7cHJvcHMuYXZhaWxhYmlsaXR5LmF2YWlsYWJpbGl0eSA/ICdpdGVtQXZhaWxhYmlsaXR5R3JlZW4nIDogJ2l0ZW1BdmFpbGFiaWxpdHlSZWQnfWB9Pntwcm9wcy5hdmFpbGFiaWxpdHkuYXZhaWxhYmlsaXR5ID8gXCJBdmFpbGFibGUgYXQ6XCI6IFwiTm90IEF2YWlsYWJsZSBhdDpcIn08L2Rpdj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwibG9jYWxTdG9yZUF2YWlsYWJpbGl0eVwiPlxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJwaWNrdXBTdG9yZU5hbWVcIj57cHJvcHMuYXZhaWxhYmlsaXR5LnN0b3JlTmFtZS50b1VwcGVyQ2FzZSgpfTwvc3Bhbj5cbiAgICAgICAgPGEgY2xhc3NOYW1lPVwiY2hhbmdlU3RvcmVcIj5DaGFuZ2UgU3RvcmU8L2E+XG4gICAgICA8L2Rpdj5cbiAgICAgIDxidXR0b24gZGlzYWJsZWQ9eyFwcm9wcy5hdmFpbGFiaWxpdHkuYXZhaWxhYmlsaXR5fSBjbGFzc05hbWU9XCJkZWxpdmVyUGlja3VwQnV0dG9uXCI+e3Byb3BzLmF2YWlsYWJpbGl0eS5hdmFpbGFiaWxpdHkgPyBcIkFkZCB0byBDYXJ0XCI6IFwiTm90IEF2YWlsYWJsZVwifTwvYnV0dG9uPlxuICAgIDwvZGl2PlxuICA8L2Rpdj5cbilcblxuZXhwb3J0IGRlZmF1bHQgRGVsaXZlclBpY2t1cDtcbiJdLCJtYXBwaW5ncyI6IkFBQUE7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQUNBO0FBQUE7QUFDQTtBQUFBO0FBQ0E7QUFBQTtBQUNBO0FBQUE7QUFDQTtBQUFBO0FBQ0E7QUFBQTtBQUNBO0FBQUE7QUFBQTtBQUFBO0FBRUE7QUFBQTtBQUNBO0FBQUE7QUFDQTtBQUFBO0FBR0E7QUFBQTtBQUNBO0FBQUE7QUFDQTtBQUFBO0FBR0E7QUFBQTtBQUNBO0FBQUE7QUFDQTtBQUFBO0FBQ0E7QUFBQTtBQUNBO0FBQUE7QUFFQTtBQUFBO0FBQUE7QUF4QkE7QUFDQTtBQTRCQSIsInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./react-client/src/DeliverPickup.jsx\n");

/***/ }),

/***/ "./react-client/src/index.jsx":
/*!************************************!*\
  !*** ./react-client/src/index.jsx ***!
  \************************************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-dom */ \"react-dom\");\n/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_dom__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! jquery */ \"jquery\");\n/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(jquery__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var _DeliverPickup_jsx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./DeliverPickup.jsx */ \"./react-client/src/DeliverPickup.jsx\");\n/* harmony import */ var _config_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../config.js */ \"./config.js\");\n/* harmony import */ var _config_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_config_js__WEBPACK_IMPORTED_MODULE_4__);\nfunction _typeof(obj) { \"@babel/helpers - typeof\"; if (typeof Symbol === \"function\" && typeof Symbol.iterator === \"symbol\") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === \"function\" && obj.constructor === Symbol && obj !== Symbol.prototype ? \"symbol\" : typeof obj; }; } return _typeof(obj); }\n\nfunction _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError(\"Cannot call a class as a function\"); } }\n\nfunction _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if (\"value\" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }\n\nfunction _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }\n\nfunction _inherits(subClass, superClass) { if (typeof superClass !== \"function\" && superClass !== null) { throw new TypeError(\"Super expression must either be null or a function\"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }\n\nfunction _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }\n\nfunction _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = _getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn(this, result); }; }\n\nfunction _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === \"object\" || typeof call === \"function\")) { return call; } return _assertThisInitialized(self); }\n\nfunction _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError(\"this hasn't been initialised - super() hasn't been called\"); } return self; }\n\nfunction _isNativeReflectConstruct() { if (typeof Reflect === \"undefined\" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === \"function\") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }\n\nfunction _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }\n\n\n\n\n\n\n\nvar App = /*#__PURE__*/function (_React$Component) {\n  _inherits(App, _React$Component);\n\n  var _super = _createSuper(App);\n\n  function App(props) {\n    var _this;\n\n    _classCallCheck(this, App);\n\n    _this = _super.call(this, props);\n    _this.state = {\n      itemAvailability: [{\n        storeName: 'N Walnut Creek',\n        storeAddress: '2820 Ygnacio Valley Rd Walnut Creek, CA 94598',\n        storePhoneNumber: '925-433-4194',\n        availability: true\n      }],\n      itemPrice: 22,\n      itemCurrency: \"$\"\n    };\n    return _this;\n  }\n\n  _createClass(App, [{\n    key: \"componentDidMount\",\n    value: function componentDidMount() {\n      var _this2 = this;\n\n      console.log('Item id', this.props.itemId);\n      jquery__WEBPACK_IMPORTED_MODULE_2___default.a.ajax({\n        url: _config_js__WEBPACK_IMPORTED_MODULE_4___default.a.itemPrice + this.props.itemId,\n        type: \"get\",\n        success: function success(data) {\n          console.log('Data returned from the title and price service', data);\n\n          _this2.setState({\n            itemPrice: data.price,\n            itemCurrency: data.currency\n          });\n        },\n        error: function error(_error) {\n          console.log(_error);\n        }\n      });\n      jquery__WEBPACK_IMPORTED_MODULE_2___default.a.ajax({\n        url: _config_js__WEBPACK_IMPORTED_MODULE_4___default.a.availableAt + this.props.itemId,\n        type: \"get\",\n        success: function success(data) {\n          console.log('Data returned from the server', data.itemAvailability[0].storeName);\n\n          _this2.setState({\n            itemAvailability: data.itemAvailability\n          });\n        },\n        error: function error(_error2) {\n          console.log(_error2);\n        }\n      });\n    }\n  }, {\n    key: \"render\",\n    value: function render() {\n      var defaultStore = this.state.itemAvailability ? this.state.itemAvailability[0] : null;\n      return defaultStore && this.state.itemPrice ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_DeliverPickup_jsx__WEBPACK_IMPORTED_MODULE_3__[\"default\"], {\n        availability: defaultStore,\n        price: this.state.itemPrice,\n        currency: this.state.itemCurrency\n      }) : null;\n    }\n  }]);\n\n  return App;\n}(react__WEBPACK_IMPORTED_MODULE_0___default.a.Component);\n\nvar urlParams = new URLSearchParams(window.location.search);\nvar itemId = urlParams.get('itemID');\nreact_dom__WEBPACK_IMPORTED_MODULE_1___default.a.render( /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(App, {\n  itemId: itemId\n}), document.getElementById('itemAvailability'));//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9yZWFjdC1jbGllbnQvc3JjL2luZGV4LmpzeC5qcyIsInNvdXJjZXMiOlsid2VicGFjazovLy8uL3JlYWN0LWNsaWVudC9zcmMvaW5kZXguanN4P2QyYTYiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCBSZWFjdERPTSBmcm9tICdyZWFjdC1kb20nO1xuaW1wb3J0ICQgZnJvbSAnanF1ZXJ5JztcbmltcG9ydCBEZWxpdmVyUGlja3VwIGZyb20gJy4vRGVsaXZlclBpY2t1cC5qc3gnXG5pbXBvcnQgY29uZmlnIGZyb20gJy4uLy4uL2NvbmZpZy5qcydcblxuY2xhc3MgQXBwIGV4dGVuZHMgUmVhY3QuQ29tcG9uZW50IHtcbiAgY29uc3RydWN0b3IocHJvcHMpIHtcbiAgICBzdXBlcihwcm9wcyk7XG4gICAgdGhpcy5zdGF0ZSA9IHtcbiAgICAgIGl0ZW1BdmFpbGFiaWxpdHk6IFt7c3RvcmVOYW1lOiAnTiBXYWxudXQgQ3JlZWsnLFxuICAgICAgc3RvcmVBZGRyZXNzOiAnMjgyMCBZZ25hY2lvIFZhbGxleSBSZCBXYWxudXQgQ3JlZWssIENBIDk0NTk4JyxcbiAgICAgIHN0b3JlUGhvbmVOdW1iZXI6ICc5MjUtNDMzLTQxOTQnLFxuICAgICAgYXZhaWxhYmlsaXR5OiB0cnVlfV0sXG4gICAgICBpdGVtUHJpY2U6IDIyLFxuICAgICAgaXRlbUN1cnJlbmN5OiBcIiRcIlxuICAgIH1cbiAgfVxuXG4gIGNvbXBvbmVudERpZE1vdW50ICgpIHtcbiAgICBjb25zb2xlLmxvZygnSXRlbSBpZCcsIHRoaXMucHJvcHMuaXRlbUlkKVxuICAgICQuYWpheCAoe1xuICAgICAgdXJsOiBjb25maWcuaXRlbVByaWNlICsgdGhpcy5wcm9wcy5pdGVtSWQsXG4gICAgICB0eXBlOiBcImdldFwiLFxuICAgICAgc3VjY2VzczogKGRhdGEpID0+IHtcbiAgICAgICAgY29uc29sZS5sb2coJ0RhdGEgcmV0dXJuZWQgZnJvbSB0aGUgdGl0bGUgYW5kIHByaWNlIHNlcnZpY2UnLCBkYXRhKTtcbiAgICAgICAgdGhpcy5zZXRTdGF0ZSh7XG4gICAgICAgICAgaXRlbVByaWNlOiBkYXRhLnByaWNlLFxuICAgICAgICAgIGl0ZW1DdXJyZW5jeTogZGF0YS5jdXJyZW5jeVxuICAgICAgICB9KVxuICAgICAgfSxcbiAgICAgIGVycm9yOiAoZXJyb3IpID0+IHtcbiAgICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xuICAgICAgfVxuICAgIH0pXG4gICAgJC5hamF4ICh7XG4gICAgICB1cmw6IGNvbmZpZy5hdmFpbGFibGVBdCArIHRoaXMucHJvcHMuaXRlbUlkLFxuICAgICAgdHlwZTogXCJnZXRcIixcbiAgICAgIHN1Y2Nlc3M6IChkYXRhKSA9PiB7XG4gICAgICAgIGNvbnNvbGUubG9nKCdEYXRhIHJldHVybmVkIGZyb20gdGhlIHNlcnZlcicsIGRhdGEuaXRlbUF2YWlsYWJpbGl0eVswXS5zdG9yZU5hbWUpO1xuICAgICAgICB0aGlzLnNldFN0YXRlKHtcbiAgICAgICAgICBpdGVtQXZhaWxhYmlsaXR5OiBkYXRhLml0ZW1BdmFpbGFiaWxpdHlcbiAgICAgICAgfSlcbiAgICAgIH0sXG4gICAgICBlcnJvcjogKGVycm9yKSA9PiB7XG4gICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcbiAgICAgIH1cbiAgICB9KVxuICB9XG5cbiAgcmVuZGVyKCkge1xuICAgIGxldCBkZWZhdWx0U3RvcmUgPSB0aGlzLnN0YXRlLml0ZW1BdmFpbGFiaWxpdHkgPyB0aGlzLnN0YXRlLml0ZW1BdmFpbGFiaWxpdHlbMF06IG51bGw7XG4gICAgcmV0dXJuIChcbiAgICAgIChkZWZhdWx0U3RvcmUgJiYgdGhpcy5zdGF0ZS5pdGVtUHJpY2UpXG4gICAgICAgID8gPERlbGl2ZXJQaWNrdXAgYXZhaWxhYmlsaXR5PXtkZWZhdWx0U3RvcmV9IHByaWNlPXt0aGlzLnN0YXRlLml0ZW1QcmljZX0gY3VycmVuY3k9e3RoaXMuc3RhdGUuaXRlbUN1cnJlbmN5fS8+XG4gICAgICAgIDogbnVsbFxuICAgICk7XG4gIH1cbn1cblxuY29uc3QgdXJsUGFyYW1zID0gbmV3IFVSTFNlYXJjaFBhcmFtcyh3aW5kb3cubG9jYXRpb24uc2VhcmNoKTtcbmNvbnN0IGl0ZW1JZCA9IHVybFBhcmFtcy5nZXQoJ2l0ZW1JRCcpO1xuUmVhY3RET00ucmVuZGVyKDxBcHAgaXRlbUlkPXtpdGVtSWR9Lz4sIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdpdGVtQXZhaWxhYmlsaXR5JykpO1xuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7OztBQUNBO0FBQUE7QUFDQTtBQURBO0FBQ0E7QUFBQTtBQUNBO0FBQ0E7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUhBO0FBSUE7QUFDQTtBQU5BO0FBRkE7QUFVQTtBQUNBOzs7QUFDQTtBQUFBO0FBQ0E7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUFBO0FBQ0E7QUFDQTtBQUZBO0FBSUE7QUFDQTtBQUNBO0FBQ0E7QUFaQTtBQWNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUFBO0FBQ0E7QUFEQTtBQUdBO0FBQ0E7QUFDQTtBQUNBO0FBWEE7QUFhQTs7O0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFBQTtBQUFBO0FBQUE7QUFHQTs7OztBQW5EQTtBQUNBO0FBcURBO0FBQ0E7QUFDQTtBQUFBO0FBQUEiLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./react-client/src/index.jsx\n");

/***/ }),

/***/ "jquery":
/*!*************************!*\
  !*** external "jQuery" ***!
  \*************************/
/*! no static exports found */
/***/ (function(module, exports) {

eval("module.exports = jQuery;//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoianF1ZXJ5LmpzIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwialF1ZXJ5XCI/Y2QwYyJdLCJzb3VyY2VzQ29udGVudCI6WyJtb2R1bGUuZXhwb3J0cyA9IGpRdWVyeTsiXSwibWFwcGluZ3MiOiJBQUFBIiwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///jquery\n");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "React" ***!
  \************************/
/*! no static exports found */
/***/ (function(module, exports) {

eval("module.exports = React;//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicmVhY3QuanMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJSZWFjdFwiP2M0ODEiXSwic291cmNlc0NvbnRlbnQiOlsibW9kdWxlLmV4cG9ydHMgPSBSZWFjdDsiXSwibWFwcGluZ3MiOiJBQUFBIiwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///react\n");

/***/ }),

/***/ "react-dom":
/*!***************************!*\
  !*** external "ReactDOM" ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports) {

eval("module.exports = ReactDOM;//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicmVhY3QtZG9tLmpzIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwiUmVhY3RET01cIj80YjJkIl0sInNvdXJjZXNDb250ZW50IjpbIm1vZHVsZS5leHBvcnRzID0gUmVhY3RET007Il0sIm1hcHBpbmdzIjoiQUFBQSIsInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///react-dom\n");

/***/ })

/******/ });